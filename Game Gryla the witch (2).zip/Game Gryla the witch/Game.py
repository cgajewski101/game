#print dialogue
import os.path
import random
path= 'Thehouseinthewoods.txt'

checkFile = os.path.isfile(path)

infile = open(path,'r')
readFile = infile.read()
print(readFile)
#get both dialogues to print
#get it to loop with while statement
choice=False

while choice == False:
    try:
        choice = int(input('what will you do, 1)enter or 2)flee:'))
    except:
        print('must be an integer')

path = 'thelargeroom.txt'
path2 = 'youfled.txt'

if choice==1:
    infile = open(path,'r')
    readFile = infile.read()
    print(readFile)

if choice==2:
    infile = open(path2,'r')
    readFile = infile.read()
    print(readFile)

#table, basement, and kitchen
choice=False

while choice == False:
    try:
        choice = int(input('what will you do 1)search the table 2)enter the door to your right or 3) walk down the stairs:'))
    except:
        print('must be an integer')

path3 = 'table.txt'
path4 = 'kitchen.txt'
path5 = 'basement.txt'
path6 = 'basementplusweapon.txt'

if choice==1:
    infile = open(path3,'r')
    readFile = infile.read()
    print(readFile)

if choice==2:
    infile = open(path4,'r')
    readFile = infile.read()
    print(readFile)

if choice==3:
    infile = open(path5,'r')
    readFile = infile.read()
    print(readFile)

if choice==1:
    choice=False

    while choice == False:
         try:
            choice = int(input('what will you do 4)enter the door to your right or 5) walk down the stairs:'))
         except:
            print('must be an integer')

if choice==4:
    infile = open(path4,'r')
    readFile = infile.read()
    print(readFile)

if choice==5:
    infile = open(path5,'r')
    readFile = infile.read()
    print(readFile)

if choice==4:
     try:
        choice = int(input('what will you do 6)walk down the stairs:'))
     except:
        print('must be an integer')
        
if choice==6:
    infile = open(path6,'r')
    readFile = infile.read()
    print(readFile)

if choice==2:
    choice=False

    while choice == False:
         try:
            choice = int(input('what will you do 7)search the table or 8) walk down the stairs:'))
         except:
            print('must be an integer')

if choice==7:
    infile = open(path3,'r')
    readFile = infile.read()
    print(readFile)

if choice==8:
    infile = open(path5,'r')
    readFile = infile.read()
    print(readFile)

if choice==7:
    choice=False

    while choice == False:
         try:
            choice = int(input('what will you do 9) walk down the stairs:'))
         except:
            print('must be an integer')

if choice==9:
    infile = open(path6,'r')
    readFile = infile.read()
    print(readFile)

choice=False

while choice == False:
    try:
        choice = int(input('what will you do, 1)Attack 2)Pursuade or 3)consider Gryla more carefully:'))
    except:
        print('must be an integer')

if choice==1:

    for rolls in range (1):
        randomDice = random.randrange(20)+2
        print(randomDice)
    if randomDice>=20:
        print('critical hit')
    if randomDice==1:
        print('critical fail')
    if randomDice<=19:
        print('game over')
    
if choice==2:

    for rolls in range (1):
        randomDice = random.randrange(20)+2
        print(randomDice)
    if randomDice>=20:
        print('critical hit')
    if randomDice==1:
        print('critical fail')
    if randomDice<=19:
        print('game over')

if choice==3:

    for rolls in range (1):
        randomDice = random.randrange(20)+2
        print(randomDice)
    if randomDice>=20:
        print('critical hit')
    if randomDice==1:
        print('critical fail')
    if randomDice<=19:
        print('game over')

path = 'defeatedgryla.txt'

if randomDice==20:
    infile = open(path,'r')
    readFile = infile.read()
    print(readFile)

