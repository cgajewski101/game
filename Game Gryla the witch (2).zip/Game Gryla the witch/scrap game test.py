#dice roll
#import random

for rolls in range (3):
    randomDice = random.randrange(20)+1
    print(randomDice)
    if randomDice==20:
        print('critical hit')
    if randomDice==1:
        print('critical fail')
        
            
#print ('done rolling')

#make the dice rolling not based on input but based on if they get a hit
#try for loop

#get both dialogues to print
#get game over dialogue to loop
#import os.path
#choice=False   
#while choice == False:
#    try:
#        choice = int(input('what will you do, 1)enter or 2)flee:'))
#    except:
#        print('must be an integer')
        
#path = 'thelargeroom.txt'
#path2 = 'youfled.txt'

#if choice==1:
#    infile = open(path,'r')
#    readFile = infile.read()
#    print(readFile)
    
#if choice==2:
#    infile = open(path2,'r')
#    readFile = infile.read()
#    print(readFile)



